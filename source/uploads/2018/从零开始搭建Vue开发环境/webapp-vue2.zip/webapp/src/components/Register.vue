<template>
    <div>
        <h3>注册</h3>
        账号：<input type="text"><br>
        密码：<input type="password"><br>
        确认密码：<input type="password"><br>
        <input type="submit" value="提交">
    </div>
</template>
