<template>
    <div>
        <h3>登陆</h3>
        账号：<input type="text"><br>
        密码：<input type="password">
    </div>
</template>

<style lang="less" scoped>
    
</style>