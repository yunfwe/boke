import Vue from "vue"
import App from "./App.vue"

import router from "./router.js"

let vm = new Vue({
    el: "#app",
    render: function(createElement){
        return createElement(App)
    },
    router: router
})
