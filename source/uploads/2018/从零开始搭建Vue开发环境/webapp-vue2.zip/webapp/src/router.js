import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

import login from './components/Login.vue'
import register from './components/Register.vue'

export default new VueRouter({
    routes:[
        {path:"/login", component: login},
        {path:"/register", component: register},
    ]
})