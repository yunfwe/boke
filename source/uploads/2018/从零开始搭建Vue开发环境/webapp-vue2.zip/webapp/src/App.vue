<template>
    <div id="app">
        {{msg}}
        <br>
        <router-link to="/login">登陆</router-link>
        <router-link to="/register">注册</router-link>
        <router-view></router-view>
    </div>
</template>

<script>
import login from './components/Login.vue'
import register from './components/Register.vue'
export default {
    data(){
        return {
            msg: "Hello App!"
        }
    },
    components:{
        'login': login,
        'register': register
    }
}
</script>

<style lang="less" scoped>
    #app {
        @line: 30px;
        a {
            display: inline-block;
            width: 80px;
            height: @line;
            text-decoration: none;
            border: 1px solid skyblue;
            text-align: center;
            line-height: @line;
            border-radius: 5px;
            color: #666666;
            transition: all 0.3s ease;
            
        }
        a:hover {
            background-color: skyblue;
            color: white;
        }
        a:active {
            background-color:rgb(0, 255, 157);
        }
    }
</style>